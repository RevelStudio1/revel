# Flow — REVEL

Tablica Kanban i lista zadań, tworzenie/edycja/usuwanie, statusy, priorytety, terminy, wyszukiwanie, statystyki, notatnik z autozapisem, timer 15/25/50 minut, eksport JSON.

Nowe projekty są demonstracjami lokalnymi. Nexus: tryb regułowy i opcjonalny model AI przeglądarki (Prompt API, EN, zgodny komputer). Tempo nie dokonuje rzeczywistych rezerwacji. Off/Grid nie przyjmuje zamówień. Łącza między projektami wymagają pełnej paczki portfolio.

## Uruchomienie
Otwórz index.html. Dla przewidywalnego zapisu localStorage uruchom przez lokalny serwer HTTP lub hosting statyczny (na file:// zachowanie pamięci zależy od przeglądarki). Nie wymaga instalacji pakietów ani kompilacji.

PL/EN: przełącznik zapisuje wybór języka lokalnie. Treści wpisane przez użytkownika nie są automatycznie tłumaczone.

Dane aplikacji pozostają w localStorage tej przeglądarki. Nie ma kont, synchronizacji między urządzeniami ani serwera. Eksport JSON to kopia danych; aplikacja nie ma funkcji importu. Reset usuwa bieżące dane po potwierdzeniu. Timer Flow nie jest odtwarzany po odświeżeniu.

Sklep Forma jest demonstracją: bez prawdziwych zamówień, płatności, dostępności magazynowej i wysyłki. Produkty, ilustracje i ceny są przykładowe. Atlas nie dokonuje rezerwacji i nie podaje aktualnych rekomendacji podróżnych.

Kod: HTML, CSS, JavaScript. Wizualizacje produktów i krajobraz zostały wygenerowane do projektu. Brak zewnętrznych fontów i trackerów.

Sprawdzono składnię JavaScript, odnośniki, pokrycie tłumaczeń i testy obliczeń. Test w przeglądarce pozostał niedostępny z powodu infrastruktury podglądu — wykonaj go przed docelową publikacją.

© 2026 REVEL.
